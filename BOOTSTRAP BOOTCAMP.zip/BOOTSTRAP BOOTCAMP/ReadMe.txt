this project was completed on 02/27/2022
website was made with .
Boostrap 
Html
Css
.. first project completed after a 20+ hours of coding
have been procastinating alot completing this task makes me feel very good; hahahhah
i guess this marks the start of a new beginning 
wlle let see ..
